// g2o - General Graph Optimization
// Copyright (C) 2011 R. Kuemmerle, G. Grisetti, W. Burgard
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are
// met:
//
// * Redistributions of source code must retain the above copyright notice,
//   this list of conditions and the following disclaimer.
// * Redistributions in binary form must reproduce the above copyright
//   notice, this list of conditions and the following disclaimer in the
//   documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
// IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
// TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
// PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
// TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
// LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

#include "edge_xyz_prior.h"
#include <iostream>

namespace g2o {
  using namespace std;

  EdgeXYZPrior::EdgeXYZPrior() : BaseUnaryEdge<3, Vector3, VertexPointXYZ>() {
    information().setIdentity();
  }

  bool EdgeXYZPrior::read(std::istream& is) {
    // read measurement
    Vector3 meas;
    for (int i=0; i<3; i++) is >> meas[i];
    setMeasurement(meas);
    // read covariance matrix (upper triangle)
    if (is.good()) {
      for ( int i=0; i<information().rows(); i++)
        for (int j=i; j<information().cols(); j++){
          is >> information()(i,j);
          if (i!=j)
            information()(j,i)=information()(i,j);
        }
    }
    return !is.fail();
  }

  bool EdgeXYZPrior::write(std::ostream& os) const {
    for (int i = 0; i<3; i++) os << measurement()[i] << " ";
    for (int i=0; i<information().rows(); i++)
      for (int j=i; j<information().cols(); j++) {
        os << information()(i,j) << " ";
      }
    return os.good();
  }

  void EdgeXYZPrior::computeError() {
    const VertexPointXYZ* v = static_cast<const VertexPointXYZ*>(_vertices[0]);
    _error = v->estimate() - _measurement;
  }

  void EdgeXYZPrior::linearizeOplus(){
      _jacobianOplusXi = Matrix3::Identity();
  }

  bool EdgeXYZPrior::setMeasurementFromState(){
      const VertexPointXYZ* v = static_cast<const VertexPointXYZ*>(_vertices[0]);
      _measurement = v->estimate();
      return true;
  }
}
